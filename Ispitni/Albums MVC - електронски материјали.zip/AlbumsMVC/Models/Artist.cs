﻿using System.ComponentModel.DataAnnotations;

namespace AlbumsMVC.Models
{
    public class Artist
    {
        public int ArtistId { get; set; }
        [Display(Name = "Artist Name")]
        [Required]
        public string Name { get; set; }
    }
}