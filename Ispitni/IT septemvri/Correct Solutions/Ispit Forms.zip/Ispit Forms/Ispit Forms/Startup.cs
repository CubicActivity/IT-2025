﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Ispit_Forms.Startup))]
namespace Ispit_Forms
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
