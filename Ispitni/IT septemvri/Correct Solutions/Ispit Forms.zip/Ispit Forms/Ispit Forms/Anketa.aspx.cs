﻿using Microsoft.Owin;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Ispit_Forms
{
    public partial class Anketa : System.Web.UI.Page
    {
        static decimal sum = 0;
        static int counter = 0;
        static string institucija = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (!Page.IsPostBack) {
                Image1.Width=300;
                
                institucija =""+ Page.ClientQueryString.ToString()[12] + Page.ClientQueryString.ToString()[13]; 

                if (institucija == "mo")
                {
                    Image1.ImageUrl = "~/Logos/mon.png";
                    Label1.Text = "Министерство за Образование";

                    ListItem item1 = new ListItem();
                    item1.Text = "Основно образование";
                    item1.Value = "1";

                    ListItem item2 = new ListItem();
                    item2.Text = "Средно образование";
                    item2.Value = "2";

                    ListItem item3 = new ListItem();
                    item3.Text = "Високо образование";
                    item3.Value = "3";

                    ListBox1.Items.Add(item1);
                    ListBox1.Items.Add(item2);
                    ListBox1.Items.Add(item3);

                    for (int i = 1; i < 4; i++) {
                        ListItem item4 = new ListItem();
                        item4.Text = "Внеси " + i;
                        ListBox2.Items.Add(item4);
                    }

                }
                else if (institucija == "me")
                {
                    Image1.ImageUrl = "~/Logos/mer.png";
                    Label1.Text = "Министерство за Енергетика";

                    ListItem item1 = new ListItem();
                    item1.Text = "Електрична енергија";
                    item1.Value = "1";

                    ListItem item2 = new ListItem();
                    item2.Text = "Централно греење";
                    item2.Value = "2";

                    ListBox1.Items.Add(item1);
                    ListBox1.Items.Add(item2);

                    for (int i = 1; i < 3; i++)
                    {
                        ListItem item3 = new ListItem();
                        item3.Text = "Внеси " + i;
                        ListBox2.Items.Add(item3);
                    }
                }
                else if (institucija == "mz") {
                    Image1.ImageUrl = "~/Logos/mz.jpg";
                    Label1.Text = "Министерство за Здравство";

                    ListItem item1 = new ListItem();
                    item1.Text = "Јавно здравје";
                    item1.Value = "1";

                    ListItem item2 = new ListItem();
                    item2.Text = "Вакцинација";
                    item2.Value = "2";

                    ListItem item3 = new ListItem();
                    item3.Text = "Матични лекари";
                    item3.Value = "3";

                    ListItem item4 = new ListItem();
                    item4.Text = "Аптеки";
                    item4.Value = "4";

                    ListBox1.Items.Add(item1);
                    ListBox1.Items.Add(item2);
                    ListBox1.Items.Add(item3);
                    ListBox1.Items.Add(item4);

                    for (int i = 1; i < 5; i++)
                    {
                        ListItem item5 = new ListItem();
                        item5.Text = "Внеси " + i;
                        ListBox2.Items.Add(item5);
                    }

                }


            }


            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (ListBox1.SelectedIndex!=-1) {
                if (ListBox2.SelectedIndex == ListBox1.SelectedIndex && ListBox2.SelectedItem.Text[0]=='В')
                {
                        if(TextBox1.Text == "1" || TextBox1.Text == "2" || TextBox1.Text == "3" || TextBox1.Text == "4" || TextBox1.Text == "5")
                    {
                        ListBox2.SelectedItem.Text = TextBox1.Text;
                        sum += int.Parse(TextBox1.Text);
                        counter++;
                        ListBox2.SelectedIndex = -1;
                        Label5.Visible = false;

                        TextBox1.Text = "";
                    }
                        
                    
                }
                else
                {
                    Label5.Visible = true;
                }
                
            }
            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {

            if (institucija == "mo" && counter ==3) {
                sum /= counter;
                Session["avg"] = sum;

                Response.Redirect("Rezultati.aspx");
            }else if(institucija == "me" && counter == 2)
            {
                sum /= counter;
                Session["avg"] = sum;

                Response.Redirect("Rezultati.aspx");
            }
            else if(institucija == "mz" && counter==4)
            {
                sum /= counter;
                Session["avg"] = sum;

                Response.Redirect("Rezultati.aspx");
            }
            else
            {
                Label5.Visible = true;
            }

            
        }

        protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ListBox1.SelectedIndex != -1) {

                if (ListBox2.SelectedIndex != -1)
                {
                    int prevIndex = ListBox2.SelectedIndex;
                    ListBox2.SelectedIndex=ListBox1.SelectedIndex;
                    if (ListBox2.SelectedItem.Text[0] != 'В') {
                        ListBox2.SelectedIndex = -1;
                    }
                    else
                    {
                        ListBox2.SelectedIndex = ListBox1.SelectedIndex;
                    }
                    
                }
                else
                {
                    Label5.Visible = false;
                    ListBox2.SelectedIndex = ListBox1.SelectedIndex;
                    if (ListBox2.SelectedItem.Text[0] != 'В')
                    {
                        ListBox2.SelectedIndex = -1;
                    }

                }
            }
            
        }

        protected void ListBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ListBox2.SelectedIndex != -1)
            {
                if (ListBox2.SelectedItem.Text[0] == 'В') {
                    ListBox1.SelectedIndex = ListBox2.SelectedIndex;
                }
            }
        }
    }
}