﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Ispit_Forms
{
    public partial class Rezultati : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Text = Session["name"] + ", Ви благодариме за користење на нашиот систем. Вашиот просек на задоволство изнесува " + Math.Round(decimal.Parse(Session["avg"].ToString()),2) + ". За дополнителни информации ќе ве контактираме на" + Session["email"];
        }
    }
}