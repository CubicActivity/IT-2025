﻿using System.Web.UI;

namespace Ispit_Forms.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}