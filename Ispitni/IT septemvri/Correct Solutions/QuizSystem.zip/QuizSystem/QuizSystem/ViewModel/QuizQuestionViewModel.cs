﻿using QuizSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QuizSystem.ViewModel
{
    public class QuizQuestionViewModel
    {
        public virtual Quiz quiz { get; set; }
        public virtual List<Question> Questions { get; set; }

        public int selectedQuestionId { get; set; }
    }
}