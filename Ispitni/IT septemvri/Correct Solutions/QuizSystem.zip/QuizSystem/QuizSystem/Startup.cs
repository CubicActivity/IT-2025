﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(QuizSystem.Startup))]
namespace QuizSystem
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
