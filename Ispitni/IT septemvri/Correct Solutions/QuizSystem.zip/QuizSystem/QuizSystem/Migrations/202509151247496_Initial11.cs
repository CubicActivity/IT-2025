﻿namespace QuizSystem.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial11 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Quizs",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        SubjectId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Subjects", t => t.SubjectId, cascadeDelete: true)
                .Index(t => t.SubjectId);
            
            AddColumn("dbo.Questions", "Quiz_Id", c => c.Int());
            CreateIndex("dbo.Questions", "Quiz_Id");
            AddForeignKey("dbo.Questions", "Quiz_Id", "dbo.Quizs", "Id");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Quizs", "SubjectId", "dbo.Subjects");
            DropForeignKey("dbo.Questions", "Quiz_Id", "dbo.Quizs");
            DropIndex("dbo.Quizs", new[] { "SubjectId" });
            DropIndex("dbo.Questions", new[] { "Quiz_Id" });
            DropColumn("dbo.Questions", "Quiz_Id");
            DropTable("dbo.Quizs");
        }
    }
}
