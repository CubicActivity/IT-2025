﻿namespace QuizSystem.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial1 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Questions",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        KratkoIme = c.String(),
                        Tekst = c.String(),
                        TochenOdgovor = c.String(),
                        GreshenOdgovor1 = c.String(),
                        GreshenOdgovor2 = c.String(),
                        GreshenOdgovor3 = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Subjects",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Naslov = c.String(),
                        Profesor = c.String(),
                        Email = c.String(),
                        ImgURL = c.String(),
                        Krediti = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Subjects");
            DropTable("dbo.Questions");
        }
    }
}
