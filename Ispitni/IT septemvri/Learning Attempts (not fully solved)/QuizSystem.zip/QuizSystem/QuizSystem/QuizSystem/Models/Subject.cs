﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace QuizSystem.Models
{
    public class Subject
    {
        public int Id { get; set; }
        [Required]
        public string Naslov { get; set; }
        [Required]
        public string Profesor { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        public string ImgURL { get; set; }
        [Required]
        [Range(3,12)]
        public int Krediti { get; set; }
    }
}