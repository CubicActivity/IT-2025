﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace QuizSystem.Models
{
    public class Question
    {
        public int Id { get; set; }
        [Required]
        public string KratkoIme { get; set; }
        [Required]
        public string Tekst { get; set; }
        [Required]
        public string TochenOdgovor { get; set; }
        [Required]
        public string GreshenOdgovor1 { get; set; }
        [Required]
        public string GreshenOdgovor2 { get; set; }
        [Required]
        public string GreshenOdgovor3 { get; set; }
    }
}