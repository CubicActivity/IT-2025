﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace QuizSystem.Models
{
    public class Quiz
    {

        public int Id { get; set; }
        [Required]
        public string Name { get; set; }

        // dodadete gi potrebnite relacii za predmet i prashanja

        public List<Question> questions { get; set; }
    }
}