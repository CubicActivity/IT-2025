﻿namespace QuizSystem.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class initial4 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Questions", "KratkoIme", c => c.String(nullable: false));
            AlterColumn("dbo.Questions", "Tekst", c => c.String(nullable: false));
            AlterColumn("dbo.Questions", "TochenOdgovor", c => c.String(nullable: false));
            AlterColumn("dbo.Questions", "GreshenOdgovor1", c => c.String(nullable: false));
            AlterColumn("dbo.Questions", "GreshenOdgovor2", c => c.String(nullable: false));
            AlterColumn("dbo.Questions", "GreshenOdgovor3", c => c.String(nullable: false));
            AlterColumn("dbo.Quizs", "Name", c => c.String(nullable: false));
            AlterColumn("dbo.Subjects", "Naslov", c => c.String(nullable: false));
            AlterColumn("dbo.Subjects", "Profesor", c => c.String(nullable: false));
            AlterColumn("dbo.Subjects", "Email", c => c.String(nullable: false));
            AlterColumn("dbo.Subjects", "ImgURL", c => c.String(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Subjects", "ImgURL", c => c.String());
            AlterColumn("dbo.Subjects", "Email", c => c.String());
            AlterColumn("dbo.Subjects", "Profesor", c => c.String());
            AlterColumn("dbo.Subjects", "Naslov", c => c.String());
            AlterColumn("dbo.Quizs", "Name", c => c.String());
            AlterColumn("dbo.Questions", "GreshenOdgovor3", c => c.String());
            AlterColumn("dbo.Questions", "GreshenOdgovor2", c => c.String());
            AlterColumn("dbo.Questions", "GreshenOdgovor1", c => c.String());
            AlterColumn("dbo.Questions", "TochenOdgovor", c => c.String());
            AlterColumn("dbo.Questions", "Tekst", c => c.String());
            AlterColumn("dbo.Questions", "KratkoIme", c => c.String());
        }
    }
}
