﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QuizSystem.Models
{
    public class Question
    {
        public int Id { get; set; }
        public string KratkoIme { get; set; }
        public string Tekst { get; set; }
        public string TochenOdgovor { get; set; }
        public string GreshenOdgovor1 { get; set; }
        public string GreshenOdgovor2 { get; set; }
        public string GreshenOdgovor3 { get; set; }
    }
}