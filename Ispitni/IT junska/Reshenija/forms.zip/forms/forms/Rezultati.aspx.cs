﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace forms
{
    public partial class Rezultati : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            Label1.Text = Session["ime"] as string +", Ви благодариме за користење на нашиот систем. Вашиот просек\r\nна задоволство изнесува" + Session["grade"] +". За дополнителни информации ќе ве\r\nконтактираме на "+ Session["email"] as string ;
        }
    }
}