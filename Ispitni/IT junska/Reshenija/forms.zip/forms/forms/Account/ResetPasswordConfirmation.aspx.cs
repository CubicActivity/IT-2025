﻿using System.Web.UI;

namespace forms.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}