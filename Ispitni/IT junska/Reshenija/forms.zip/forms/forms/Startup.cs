﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(forms.Startup))]
namespace forms
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
