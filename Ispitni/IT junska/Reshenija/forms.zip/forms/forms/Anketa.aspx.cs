﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace forms
{
    public partial class Anketa : System.Web.UI.Page
    {
        public int count=1;
        protected void Page_Load(object sender, EventArgs e)
        {
            string type = Request.QueryString["url"];
            if(type == "mon")
            {
                Image1.ImageUrl = "Logos/mon.png";
                ime.Text = "Министерство за образование";
                uslugi.Items.Clear();
                grades.Items.Clear();
                count = 1;
                foreach (ListItem item in uslugi0.Items)
                {
                    if (item.Value == "mon")
                    {
                        uslugi.Items.Add(item);
                        ListItem item2 = new ListItem();
                        item2.Text = "Внеси " + count;
                        item2.Value = count.ToString();
                        grades.Items.Add(item2);
                        count++;
                    }
                }

            }
            else if(type == "mer")
            {
                Image1.ImageUrl = "Logos/mer.png";
                ime.Text = "Министерство за енергетика";
                uslugi.Items.Clear();
                grades.Items.Clear();
                count = 1;
                foreach (ListItem item in uslugi0.Items)
                {

                    if (item.Value == "mer")
                    {
                        uslugi.Items.Add(item);
                        ListItem item2 = new ListItem();
                        item2.Text = "Внеси " + count;
                        item2.Value = count.ToString();
                        grades.Items.Add(item2);
                        count++;
                    }
                }
            }
            else if (type == "mz")
            {
                Image1.ImageUrl = "Logos/mz.jpg";
                ime.Text = "Министерство за Здравство";
                uslugi.Items.Clear();
                grades.Items.Clear();
                count = 1;
                foreach (ListItem item in uslugi0.Items)
                {
                    if (item.Value == "mz")
                    {
                        uslugi.Items.Add(item);
                        ListItem item2 = new ListItem();
                        item2.Text = "Внеси " + count;
                        item2.Value = count.ToString();
                        grades.Items.Add(item2);
                        count++;
                    }
                }
            }
        }

        protected void uslugi_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            grades.SelectedItem.Text = TextBox1.Text;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            int num = 0;
            int sum = 0;

            foreach(ListItem item in uslugi.Items)
            {
                num++;
            }

            foreach(ListItem item in grades.Items)
            {
                sum += int.Parse(item.Value);
               
            }

            Session["grade"] = (double)sum/num;
            Response.Redirect("Rezultati");
        }

        protected void grades_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}