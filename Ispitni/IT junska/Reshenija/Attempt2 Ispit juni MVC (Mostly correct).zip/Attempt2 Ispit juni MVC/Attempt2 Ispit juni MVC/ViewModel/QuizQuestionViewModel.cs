﻿using Attempt2_Ispit_juni_MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Attempt2_Ispit_juni_MVC.ViewModel
{
    public class QuizQuestionViewModel
    {
        public virtual Quiz Quiz { get; set; }
        public virtual List<Question> Questions { get; set; }


        public int SelectedQuestionId { get; set; } // Just a single int for the chosen question
    }
}