﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Attempt2_Ispit_juni_MVC.Models;
using Attempt2_Ispit_juni_MVC.ViewModel;

namespace Attempt2_Ispit_juni_MVC.Controllers
{
    public class QuizsController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Quizs
        [AllowAnonymous]
        public ActionResult Index()
        {
            var quizs = db.Quizs.Include(q => q.Subject);
            return View(quizs.ToList());
        }

        // GET: Quizs/Details/5
        [Authorize]
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Quiz quiz = db.Quizs.Find(id);
            if (quiz == null)
            {
                return HttpNotFound();
            }
            return View(quiz);
        }

        // GET: Quizs/Create
        [Authorize]
        public ActionResult Create()
        {
            ViewBag.SubjectId = new SelectList(db.Subjects, "SubjectId", "SubjectName");
            return View();
        }

        // POST: Quizs/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult Create([Bind(Include = "QuizId,QuizName,SubjectId")] Quiz quiz)
        {
            if (ModelState.IsValid)
            {
                db.Quizs.Add(quiz);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.SubjectId = new SelectList(db.Subjects, "SubjectId", "SubjectName", quiz.SubjectId);
            return View(quiz);
        }

        // GET: Quizs/Edit/5
        [Authorize]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Quiz quiz = db.Quizs.Find(id);
            if (quiz == null)
            {
                return HttpNotFound();
            }
            ViewBag.SubjectId = new SelectList(db.Subjects, "SubjectId", "SubjectName", quiz.SubjectId);
            return View(quiz);
        }

        // POST: Quizs/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult Edit([Bind(Include = "QuizId,QuizName,SubjectId")] Quiz quiz)
        {
            if (ModelState.IsValid)
            {
                db.Entry(quiz).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.SubjectId = new SelectList(db.Subjects, "SubjectId", "SubjectName", quiz.SubjectId);
            return View(quiz);
        }

        // GET: Quizs/Delete/5
        [Authorize]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Quiz quiz = db.Quizs.Find(id);
            if (quiz == null)
            {
                return HttpNotFound();
            }
            return View(quiz);
        }

        // POST: Quizs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult DeleteConfirmed(int id)
        {
            Quiz quiz = db.Quizs.Find(id);
            db.Quizs.Remove(quiz);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        public ActionResult AddQuestion(int id) {
            List<Question> questions = db.Questions.ToList();
            Quiz quiz = db.Quizs.Find(id);

            QuizQuestionViewModel quizQuestionViewModel = new QuizQuestionViewModel{Quiz=quiz, Questions = questions};

            return View(quizQuestionViewModel);
        }

        public ActionResult AddQuestionToQuiz(int quizId, int questionId) {

            var quiz = db.Quizs.Find(quizId);
            var question = db.Questions.Find(questionId);

            if (quiz != null && question != null)
            {
                quiz.Questions.Add(question);
                db.SaveChanges();
            }

            return RedirectToAction("Details", new {id = quiz.QuizId});
        }

    }
}
