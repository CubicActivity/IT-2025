﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Attempt2_Ispit_juni_MVC.Startup))]
namespace Attempt2_Ispit_juni_MVC
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
