﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Attempt2_Ispit_juni_MVC.Models
{
    public class Quiz
    {

        public int QuizId { get; set; }

        public string QuizName { get; set; }

        public int SubjectId { get; set; }
        public virtual Subject Subject { get; set; }
        

        public virtual List<Question> Questions { get; set; }
    }
}