﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Attempt2_Ispit_juni_MVC.Models
{
    public class Question
    {
        public int QuestionId { get; set; }
        public string Shortname { get; set; }
        public string Text { get; set; }
        public string CorrectAnswer { get; set; }
        public string IncorrectAnswer1 { get; set; }
        public string IncorrectAnswer2 { get; set; }
        public string IncorrectAnswer3 { get; set; }

    }
}