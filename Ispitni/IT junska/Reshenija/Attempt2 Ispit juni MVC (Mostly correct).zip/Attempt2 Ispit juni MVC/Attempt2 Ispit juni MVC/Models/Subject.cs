﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Attempt2_Ispit_juni_MVC.Models
{
    public class Subject
    {
        public int SubjectId { get; set; }
        public string SubjectName { get; set; }
        public string professor { get; set; }
        public string imgURL { get; set; }
        [Range(3, 12)]
        public int credits;
        [EmailAddress]
        public string Email { get; set; }
    }
}